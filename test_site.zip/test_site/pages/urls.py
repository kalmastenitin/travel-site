from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about', views.about, name='about'),
    # path('destination', views.destination, name='destination'),
    path('hotel-restro', views.hotel_restro, name='hotel-resto'),
    # path('blog',views.blog, name='blog'),
    path('contact',views.contact, name='contact'),
    path('blog',views.blog_single, name='blog'),
]
