from django.shortcuts import render
from destinations.models import Destinations
from destinations.choices import price_choices, stay_choices

# Create your views here.
def index(request):
    destinations = Destinations.objects.order_by('-list_date').filter(is_published=True)[:4]
    context = {
    'destinations': destinations,
    'price_choices': price_choices,
    'stay_choices': stay_choices,
    }
    return render(request,'index.html',context)

def about(request):
    return render(request,'about.html')

#
# def destination(request):
#     return render(request,'destination.html')

def hotel_restro(request):
    return render(request,'hotel-resto.html')

def blog(request):
    return render(request,'blog.html')

def blog_single(request):
    return render(request,'blog_single.html')

def contact(request):
    return render(request,'contact.html')
