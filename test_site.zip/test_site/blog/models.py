from django.db import models
from datetime import datetime

class BlogPost(models.Model):
    post_title = models.CharField(max_length=100)
    post_content = models.TextField()
    post_types = (
    ('Travel', 'Travel'),
    ('Tour', 'Tour'),
    ('Destination','Destination'),
    ('Drinks', 'Drinks'),
    ('Foods', 'Foods'),
    )

    categories = models.CharField(
    max_length=10,
    choices = post_types,
    default = 'Travel',
    blank = False
    )

    photo_main = models.ImageField(upload_to='Photos/%Y/%M/%D')
    is_published = models.BooleanField(default=True)
    list_date = models.DateTimeField(default=datetime.now, blank=True)

    def __str__(self):
        return f'{self.post_title}'
