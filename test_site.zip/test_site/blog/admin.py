from django.contrib import admin
from .models import BlogPost

class BlogAdmin(admin.ModelAdmin):
    blog_display = ('id','post_title','post_content', 'post_types')

admin.site.register(BlogPost, BlogAdmin)
