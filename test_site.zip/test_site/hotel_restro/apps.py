from django.apps import AppConfig


class HotelRestroConfig(AppConfig):
    name = 'hotel_restro'
