from django.shortcuts import render
from django.shortcuts import render, get_object_or_404
from hotel_restro.choices import bedroom_choices,price_choices
from .models import Hotels_Restro
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def hotel_restro(request):
    hotel_restros = Hotels_Restro.objects.order_by('-list_date').filter(is_published=True)
    paginator = Paginator(hotel_restro,8)
    page = request.GET.get('page')
    paged_hotels = paginator.get_page(page)
    context = {
    'hotel_restros':paged_hotels,
    'price_choices': price_choices,
    'stay_choices': stay_choices,
    'capacity': capacity,
    }

    return render(request, 'hotel-resto.html', context)
