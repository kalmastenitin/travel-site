from django.contrib import admin
from .models import Hotels_Restro

# Register your models here.
class HotelsAdmin(admin.ModelAdmin):
    dist_display = ('id', 'Hotel_name', 'is_published', 'price','list_date')
    dist_display_links = ('id','Hotel_name')
    dist_editable = ('is_published',)
    list_per_page = 20

admin.site.register(Hotels_Restro,HotelsAdmin)
