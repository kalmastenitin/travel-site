from django.db import models
from datetime import datetime


class Hotels_Restro(models.Model):
    Hotel_name = models.CharField(max_length=100)
    address = models.CharField(max_length=200)
    capacity = models.IntegerField()
    trip_time = models.IntegerField()
    price = models.IntegerField()
    description = models.TextField(blank=True)
    photo_main = models.ImageField(upload_to='Photos/%Y/%M/%D')
    photo_1 = models.ImageField(upload_to='Photos/%Y/%M/%D', blank=True)
    photo_2 = models.ImageField(upload_to='Photos/%Y/%M/%D', blank=True)
    photo_3 = models.ImageField(upload_to='Photos/%Y/%M/%D', blank=True)
    photo_4 = models.ImageField(upload_to='Photos/%Y/%M/%D', blank=True)
    photo_5 = models.ImageField(upload_to='Photos/%Y/%M/%D', blank=True)
    is_published = models.BooleanField(default=True)
    list_date = models.DateTimeField(default=datetime.now, blank=True)


    def __str__(self):
        return f'{self.Hotel_name}'
