from django.contrib import admin
from .models import Destinations

# Register your models here.
class DestinationsAdmin(admin.ModelAdmin):
    dist_display = ('id', 'title', 'is_published', 'price','list_date')
    dist_display_links = ('id','title')
    dist_editable = ('is_published',)
    list_per_page = 20

admin.site.register(Destinations,DestinationsAdmin)
