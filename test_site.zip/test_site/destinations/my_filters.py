from . models import Destinations
from djang import template

@rating = Destinations.rating
def times(rating):
    return range(rating)
