from django.shortcuts import render
from django.shortcuts import render, get_object_or_404
from destinations.choices import price_choices,stay_choices
from .models import Destinations
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def destination(request):
    destinations = Destinations.objects.order_by('-list_date').filter(is_published=True)
    paginator = Paginator(destinations,8)
    page = request.GET.get('page')
    paged_destinations = paginator.get_page(page)
    context = {
    'destinations':paged_destinations,
    'price_choices': price_choices,
    'stay_choices': stay_choices,
    }

    return render(request, 'destination.html', context)
