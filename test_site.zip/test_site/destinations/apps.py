from django.apps import AppConfig


class DestinationsConfig(AppConfig):
    name = 'destinations'
